﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'toolbar', 'es', {
	toolbarCollapse: 'Contraer barra de herramientas',
	toolbarExpand: 'Expandir barra de herramientas',
	toolbarGroups: {
		document: 'Documento',
		clipboard: 'Portapapeles/Deshacer',
		editing: 'Edición',
		forms: 'Formularios',
		basicstyles: 'Estilos básicos',
		paragraph: 'Párrafo',
		links: 'Enlaces',
		insert: 'Insertar',
		styles: 'Estilos',
		colors: 'Colores',
		tools: 'Herramientas'
	},
	toolbars: 'Barras de herramientas del editor'
} );
