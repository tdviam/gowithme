<style>
html {
    overflow-y: scroll;
}
footer {
    display : none;
}
iframe {
width: 100%;
background-color: transparent;
padding: 0px;
border: 0px;
background: #fafafa;
min-height: 900px;
margin-top:-55px;
margin-bottom:1800px;
overflow-y: hidden;
}
.mob-bg {display:none;}
.newsletter{display:none;}
.footer{display:none;}
.app-bg{display:none;}
.tbar-bottom { position: relative;}
footer{display:none;}

</style>
<iframe src="//brands.datahc.com/?a_aid=<?php echo $aid; ?>&brandid=<?php echo $brandID; ?>&languageCode=EN" frameborder="0" height="100%" width="100%"></iframe>



<iframe src="http://www.cnn.com/"
frameBorder="0"
scrolling="no"
style="margin: 0px; padding: 0px; border: 0px; height: 0px;">
</iframe>