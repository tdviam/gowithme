<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="<?php echo @$metadescription; ?>">
<meta name="keywords" content="<?php echo @$metakeywords; ?>">
<meta name="author" content="PHPTRAVELS">
<title><?php echo @$pageTitle; ?></title>
<link rel="shortcut icon" href="<?php echo PT_GLOBAL_IMAGES_FOLDER.'favicon.png';?>">
<link href="<?php echo $theme_url; ?>assets/css/bootstrap.css" rel="stylesheet" media="screen">
<link href="<?php echo $theme_url; ?>style.css" rel="stylesheet">
<link href="<?php echo $theme_url; ?>assets/css/navigation.css" rel="stylesheet">
<!--<link href="<?php echo $theme_url; ?>eder.css" rel="stylesheet"> -->
<link href="<?php echo $theme_url; ?>assets/css/mobile.css" rel="stylesheet" media="screen">
<!-- facebook --> <meta property="og:title" content="<?php echo @$pageTitle; ?>"/> <meta property="og:site_name" content="<?php echo $app_settings[0]->site_title;?>"/> <meta property="og:description" content="<?php if($app_settings[0]->seo_status == "1"){echo $metadescription;}?>"/> <meta property="og:image" content="<?php echo base_url(); ?>uploads/global/favicon.png"/>  <meta property="og:url" content="<?php echo $app_settings[0]->site_url;?>/"/> <meta property="og:publisher" content="https://www.facebook.com/<?php echo $app_settings[0]->site_title;?>"/> <script type="application/ld+json">{"@context":"http://schema.org/","@type":"Organization","name":"<?php echo $app_settings[0]->site_title;?>","url":"<?php echo $app_settings[0]->site_url;?>/","logo":"<?php echo base_url(); ?>uploads/global/favicon.png","sameAs":"https://www.facebook.com/<?php echo $app_settings[0]->site_title;?>","sameAs":"https://twitter.com/<?php echo $app_settings[0]->site_title;?>","sameAs":"https://www.pinterest.com/<?php echo $app_settings[0]->site_title;?>/","sameAs":"https://plus.google.com/u/0/<?php echo $app_settings[0]->site_title;?>/posts","contactPoint":{"@type":"ContactPoint","telephone":"<?php echo $phone; ?>","contactType":"Customer Service"}}{"@context":"http://schema.org","@type":"WebSite","name":"<?php echo $app_settings[0]->site_title;?>","url":"<?php echo $app_settings[0]->site_url;?>"}  </script>
<!-- Child Theme --> <style> @import "<?php echo $theme_url; ?>assets/css/childstyle.css"; </style>
<!-- Google Maps --> <?php if (pt_main_module_available('ean') || $loadMap) { ?> <script type="text/javascript" src="//maps.googleapis.com/maps/api/js?key=<?php echo $app_settings[0]->mapApi; ?>&libraries=places"></script> <script src="<?php echo $theme_url; ?>assets/js/infobox.js"></script><?php } ?>
<!-- jQuery --> <script src="<?php echo $theme_url; ?>assets/js/jquery-1.11.2.min.js"></script>
<!-- RTL CSS --> <?php if($isRTL == "RTL"){ ?> <link href="<?php echo $theme_url; ?>RTL.css" rel="stylesheet"> <?php } ?>
<!-- Mobile Redirect --> <?php if($mSettings->mobileRedirectStatus == "Yes"){ if($ishome != "invoice"){ ?> <script>if(/Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent)){ window.location ="<?php echo $mSettings->mobileRedirectUrl; ?>";}</script> <?php } } ?>
<!--[if lt IE 7] > <link rel="stylesheet" type="text/css" href="<?php echo $theme_url; ?>assets/css/font-awesome-ie7.css" media="screen" /> <![endif]-->
<!-- Autocomplete CSS files-->
<link href="<?php echo $theme_url; ?>assets/js/autocomplete/easy-autocomplete.min.css" rel="stylesheet" type="text/css">
<!-- Autocomplete CSS files-->
<!-- Autocomplete JS files-->
<script src="<?php echo $theme_url; ?>assets/js/autocomplete/jquery.easy-autocomplete.min.js" type="text/javascript" ></script>
<!-- Autocomplete JS files-->
<script>var base_url = '<?php echo base_url(); ?>';</script>
<?php echo $app_settings[0]->google; ?>
</head>
<body>
<div id="preloader" class="loader-wrapper">
    <img src="<?php echo $theme_url; ?>assets/img/loader.gif" style="width:450px" class="center-block" alt="loading" />
    <div style="margin-top:-120px">
    <h4 class="text-center"><?php echo trans('0555');?> <strong><?php echo $app_settings[0]->site_title;?></strong></h4>
    <h5 class="text-center"><?php echo trans('0556');?></h5>
    </div>
</div>
<div class="modal <?php if($isRTL == "RTL"){ ?> right <?php } else { ?> left <?php } ?> fade" id="sidebar_left" tabindex="1" role="dialog" aria-labelledby="sidebar_left">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close go-left" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><i class="close icon-angle-<?php if($isRTL == "RTL"){ ?>right<?php } else { ?>left<?php } ?>"></i></span></button>
        <h4 class="modal-title go-text-right" id="sidebar_left"><i class="icon_set_1_icon-65 go-right"></i> <?php echo trans('0296');?></h4>
      </div>
      <?php include 'settings.php'; ?>
    </div>
  </div>
</div>
<div class="clearfix"></div>
<div class="tbar-top hidden-sm hidden-xs">
  <div class="container">
    <div class="row">
      <div class="col-md-6 col-sm-4 col-xs-7 go-right">
        <div class="contact-box">
          <ul class="hidden-sm hidden-xs">
            <?php if( ! empty($phone) ) { ?>
            <li class="go-right">
              <i class="icon_set_1_icon-55 go-right align-M mrg5-R f-grey66 fs13"></i>
              <span class="contact-no align-M"><?php echo trans('0438');?>: <a href="#tel:<?php echo $phone; ?>" class="number"><?php echo $phone; ?></a></span>
            </li>
            <?php } ?>
            <?php if( ! empty($contactemail) ) { ?>
            <li class="go-right">
              <span class="sep go-right">|</span>
              <span class="tp-mail"><a title="Mail" href="mailto:<?php echo $contactemail; ?>"><?php echo $contactemail; ?></a></span>
            </li>
            <?php } ?>
          </ul>
        </div>
      </div>
      <div class="col-md-6 col-sm-8 col-xs-5 go-left">
        <?php include 'settings.php'; ?>
      </div>
    </div>
  </div>
</div>
<div class="navbar navbar-static-top navbar-default <?php echo @$hidden; ?> hidden-lg hidden-md">
  <div class="container">
    <div class="navbar">
      <!-- Navigation-->
      <div class="navbar-header">
        <button data-toggle="modal" data-target="#sidebar_left" class="navbar-toggle go-left" type="button" style="margin-top: 30px;">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        </button>
        <a href="<?php echo base_url(); ?>" class="navbar-brand go-right loader"><img src="<?php echo PT_GLOBAL_IMAGES_FOLDER.$app_settings[0]->header_logo_img;?>" alt="<?php echo $app_settings[0]->site_title;?>" class="logo"/></a>
      </div>
      <div class="navbar-collapse collapse">
        <ul class="nav navbar-nav navbar-right currency_btn"  style="padding-top: 20px;">
          <?php include 'settings.php'; ?>
        </ul>
      </div>
    </div>
  </div>
</div>
<div class="tbar-bottom hidden-xs hidden-sm">
  <div class="container">
    <div class="row">
      <div class="col-xs-2 visible-xs pos-rel">
      </div>
      <div class="col-md-4 col-sm-3 col-xs-7 go-right">
        <a href="<?php echo base_url(); ?>" class="navbar-brand go-right loader"><img src="<?php echo PT_GLOBAL_IMAGES_FOLDER.$app_settings[0]->header_logo_img;?>" alt="<?php echo $app_settings[0]->site_title;?>" class="logo"/></a>
      </div>
      <div class="col-md-8 col-sm-9 hidden-xs go-left">
        <nav id="offcanvas-menu">
          <ul class="main-menu go-left RTL">
            <?php  if(pt_main_module_available('travelport_flight')){ ?>
            <li class="main-lnk">
              <a class="loader" href="<?php echo base_url(); ?>flight/" title="">
              <span class="nav-icon hidden-xs">
              <img src="<?php echo $theme_url; ?>assets/img/icons/flight.png" class="">
              </span>
              <span><?php echo trans('0564');?></span>
              </a>
            </li>
            <?php } ?>
            <?php  if(pt_main_module_available('Travelpayouts')){ ?>
            <li class="main-lnk">
              <a class="loader" href="<?php echo base_url(); ?>air/" title="">
              <span class="nav-icon hidden-xs">
              <img src="<?php echo $theme_url; ?>assets/img/icons/flight.png" class="">
              </span>
              <span><?php echo trans('Travelpayouts');?></span>
              </a>
            </li>
            <?php } ?>
            <?php  if(pt_main_module_available('Travelstart')){ ?>
            <li class="main-lnk">
              <a class="loader" href="<?php echo base_url(); ?>flightst/" title="">
              <span class="nav-icon hidden-xs">
              <img src="<?php echo $theme_url; ?>assets/img/icons/flight.png" class="">
              </span>
              <span><?php echo trans('Travelstart');?></span>
              </a>
            </li>
            <?php } ?>
            <?php  if(pt_main_module_available('wegoflights')){ ?>
            <li class="main-lnk">
              <a class="loader" href="<?php echo base_url(); ?>" title="">
              <span class="nav-icon hidden-xs">
              <img src="<?php echo $theme_url; ?>assets/img/icons/flight.png" class="">
              </span>
              <span><?php echo trans('Wegoflights');?></span>
              </a>
            </li>
            <?php } ?>
            <?php  if(pt_main_module_available('ean')){ ?>
            <li class="main-lnk">
              <a class="loader" href="<?php echo base_url(); ?>properties/" title="">
              <span class="nav-icon hidden-xs">
              <img src="<?php echo $theme_url; ?>assets/img/icons/hotel.png" class="">
              </span>
              <span><?php echo trans('Ean');?></span>
              </a>
            </li>
            <?php } ?>
            <?php if(module_status_check('travelpayoutshotels')){ ?>
            <li class="main-lnk">
              <a class="loader" href="<?php echo base_url('tphotels'); ?>" title="">
              <span class="nav-icon hidden-xs">
              <img src="<?php echo $theme_url; ?>assets/img/icons/hotel.png" class="">
              </span>
              <span><?php echo trans('Hotels');?></span>
              </a>
            </li>
            <?php } ?>
            <?php  if(pt_main_module_available('hotelscombined')){ ?>
            <li class="main-lnk">
              <a class="loader" href="<?php echo base_url(); ?>hotelsc/" title="">
              <span class="nav-icon hidden-xs">
              <img src="<?php echo $theme_url; ?>assets/img/icons/hotel.png" class="">
              </span>
              <span><?php echo trans('Hotelscombined');?></span>
              </a>
            </li>
            <?php } ?>
            <?php  if(pt_main_module_available('hotels')){ ?>
            <li class="main-lnk">
              <a class="loader" href="<?php echo base_url(); ?>hotels/" title="">
              <span class="nav-icon hidden-xs">
              <img src="<?php echo $theme_url; ?>assets/img/icons/hotel.png" class="">
              </span>
              <span><?php echo trans('Hotels');?></span>
              </a>
            </li>
            <?php } ?>
            <?php  if(pt_main_module_available('tours')){ ?>
            <li class="main-lnk">
              <a class="loader" href="<?php echo base_url(); ?>tours/" title="">
              <span class="nav-icon hidden-xs">
              <img src="<?php echo $theme_url; ?>assets/img/icons/tour.png" class="">
              </span>
              <span><?php echo trans('Tours');?></span>
              </a>
            </li>
            <?php } ?>
            <?php  if(pt_main_module_available('cars')){ ?>
            <li class="main-lnk">
              <a class="loader" href="<?php echo base_url(); ?>cars/" title="">
              <span class="nav-icon hidden-xs">
              <img src="<?php echo $theme_url; ?>assets/img/icons/car.png" class="">
              </span>
              <span><?php echo trans('Cars');?></span>
              </a>
            </li>
            <?php } ?>
            <?php  if(pt_main_module_available('cartrawler')){ ?>
            <li class="main-lnk">
              <a class="loader" href="<?php echo base_url(); ?>car/" title="">
              <span class="nav-icon hidden-xs">
              <img src="<?php echo $theme_url; ?>assets/img/icons/car.png" class="">
              </span>
              <span><?php echo trans('Cars');?></span>
              </a>
            </li>
            <?php } ?>
            <?php  if(pt_main_module_available('ivisa')){ ?>
            <li class="main-lnk">
              <a class="loader" href="<?php echo base_url(); ?>visa/" title="">
              <span class="nav-icon hidden-xs">
              <img src="<?php echo $theme_url; ?>assets/img/icons/visa.png" class="">
              </span>
              <span><?php echo trans('Ivisa');?></span>
              </a>
            </li>
            <?php } ?>
            <li class="main-lnk">
              <a class="loader" href="<?php echo base_url(); ?>offers/" title="">
              <span class="nav-icon hidden-xs">
              <img src="<?php echo $theme_url; ?>assets/img/icons/offers.png" class="">
              </span>
              <span><?php echo trans('Offers');?></span>
              </a>
            </li>
            <?php  if(pt_main_module_available('blog')){ ?>
            <li class="main-lnk">
              <a class="loader" href="<?php echo base_url(); ?>blog/" title="">
              <span class="nav-icon hidden-xs">
              <img src="<?php echo $theme_url; ?>assets/img/icons/blog.png" class="">
              </span>
              <span><?php echo trans('Blog');?></span>
              </a>
            </li>
            <?php } ?>
          </ul>
        </nav>
      </div>
    </div>
  </div>
</div>
<div class="color_line"></div>
<!--
<div class="navbar navbar-static-top navbar-default <?php echo @$hidden; ?>">
  <div class="container">
    <div class="navbar">
      <div class="navbar-collapse collapse">
        <ul class="nav navbar-nav navbar-left go-right">
          <li class="dropdown <?php pt_active_link();?> go-right">
           <a class="dropdown-toggle" href="<?php echo base_url(); ?>"> <?php echo trans('01');?> </a>
          </li>
          <?php if($headerMenu->hasMenu){ foreach($headerMenu->pagesInfo as $page){ ?>
          <li class="go-right <?php echo $page->dropdown." ".$page->activeLinkClass;?>">
            <a href="<?php echo $page->hrefLink;?>" class="<?php echo $page->activeLinkClass.' '.$page->dropdowntoggle;?>" <?php echo $datatoggle;?>  target="<?php echo $page->target;?>" >
              <?php echo $page->title;?>  <?php echo $page->caret;?>
            </a>
            <?php if($page->hasChild){  ?>
            <ul class="<?php echo $page->dropdownmenu;?>">
              <?php foreach($page->children as $childPage){ ?>
              <li><a href="<?php  echo $childPage->hrefLink;?>" target="<?php echo $childPage->target;?>" ><i class='<?php echo $childPage->icon;?>'></i> <?php echo $childPage->title;?></a></li>
              <?php } ?>
            </ul>
            <?php } ?>
          </li>
          <?php } } ?>
        </ul>
      </div>
    </div>
  </div>
</div>
-->
<div id="body-section">